# All/most of the Julia .jl and batch scripts for the Julia session

Batch scripts can be recognized from the ending .sh

There may be batch scripts for both Kebnekaise and Rackham (or Snowy). 
