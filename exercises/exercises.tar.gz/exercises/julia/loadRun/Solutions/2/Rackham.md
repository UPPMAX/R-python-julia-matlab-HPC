                $ ml julia/1.8.5      # Julia module
               
                julia serial-sum.jl Arg1 Arg2    # run the serial script
