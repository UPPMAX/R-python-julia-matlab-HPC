                $ julia 
                julia> 5 + 6
                julia>;
                shell> pwd 
                julia>]
                pkg> status 
                julia>?
                help?> println
