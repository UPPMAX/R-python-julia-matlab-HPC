function result = add2(x,y)
result = x+y
disp("The sum of "+x+" and "+y+" is "+result)
end
