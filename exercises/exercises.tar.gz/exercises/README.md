Directory for exercises. Subdirectories for each language.

- Python: This directory contains the .py files and .sh files that are listed in the Exercises section for Python. 
- R: same for R 

