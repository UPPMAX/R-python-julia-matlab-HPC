# This program will add two numbers that are provided by the user
     
# Get the numbers
a = int(input("Enter the first number: ")) 
b = int(input("Enter the second number: "))
     
# Add the two numbers together
sum = a + b
     
# Output the sum
print("The sum of {0} and {1} is {2}".format(a, b, sum))
